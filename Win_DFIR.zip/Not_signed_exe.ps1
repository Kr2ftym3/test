echo **************************************************** > ACRC_DFIR\Not_signed_exe.txt
echo Not_signed C:\users\*.exe  >> ACRC_DFIR\Not_signed_exe.txt
echo ---------------------------------------------------- >> ACRC_DFIR\Not_signed_exe.txt
Get-ChildItem C:\users\*.exe -Recurse -ea SilentlyContinue | ForEach-object {Get-AuthenticodeSignature $_ -ea SilentlyContinue} -ea SilentlyContinue | Where-Object {$_.status -eq "NotSigned"} >> ACRC_DFIR\Not_signed_exe.txt
Get-ChildItem C:\users\*.dll -Recurse -ea SilentlyContinue | ForEach-object {Get-AuthenticodeSignature $_ -ea SilentlyContinue} -ea SilentlyContinue | Where-Object {$_.status -eq "NotSigned"} >> ACRC_DFIR\Not_signed_exe.txt
echo ---------------------------------------------------- >> ACRC_DFIR\Not_signed_exe.txt
echo Not_signed C:\Windows\*.exe  >> ACRC_DFIR\Not_signed_exe.txt
echo ---------------------------------------------------- >> ACRC_DFIR\Not_signed_exe.txt
Get-ChildItem C:\Windows\*.exe -Recurse -ea SilentlyContinue | ForEach-object {Get-AuthenticodeSignature $_ -ea SilentlyContinue} -ea SilentlyContinue | Where-Object {$_.status -eq "NotSigned"} >> ACRC_DFIR\Not_signed_exe.txt
echo ---------------------------------------------------- >> ACRC_DFIR\Not_signed_exe.txt

echo **************************************************** > ACRC_DFIR\Susp_Process_Hash.txt
echo 'Current Process execution or module loads from temporary directories' >> ACRC_DFIR\Susp_Process_Hash.txt
echo ---------------------------------------------------- >> ACRC_DFIR\Susp_Process_Hash.txt
$A=((gps).Path|Select-String "Appdata","ProgramData","Temp","Users","public"|sort|unique);$C=foreach ($B in $A) {filehash $B | Format-List};$C >> ACRC_DFIR\Susp_Process_Hash.txt
echo **************************************************** >> ACRC_DFIR\Susp_Process_Hash.txt